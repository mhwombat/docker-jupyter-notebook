Global White Box Explainers
===========================

ProfWeight Explainer
--------------------

.. autoclass:: aix360.algorithms.profwt.profwt.ProfweightExplainer
   :members:
