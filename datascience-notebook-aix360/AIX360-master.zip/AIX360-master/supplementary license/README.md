All code in this repository is licensed under the Apache 2.0 license, except for the following files, which are licensed under either MIT license or BSD-2 license as indicated on the top of each of these files:     

aix360/datasets/mnist_dataset.py       
aix360/algorithms/profwt/resnet_keras_model.py      
aix360/algorithms/contrastive/CEM_aen.py        
aix360/algorithms/contrastive/CEM_MAF_aen_PP.py       
aix360/algorithms/contrastive/CEM_MAF_aen_PN.py       
aix360/algorithms/contrastive/CEM_MAF_utils.py        
