# Guidance on use of AI Explainability 360 algorithms 

![Guidance](methods-choice-updated.png)
